<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="jquery library/jquery.min.js"></script>  
    <script src="jquery library/Croppie-2.6.4/croppie.js"></script>
    <link rel="stylesheet" href="jquery library/Croppie-2.6.4/croppie.css" />  
    <script src="jquery library/jquery-ui-1.12.1/jquery-ui.js"></script>
    <link rel="stylesheet" href="jquery library/jquery-ui-1.12.1/jquery-ui.css" />  
    


    

 
    <title>Upload Your Photo</title>

    <style>
    form * {
    border-radius:0 !important;
    }

    form > fieldset > legend {
        font-size:120%;
    }
    
    </style>

</head>
<body>
    
<div class="container">
        <div class="row">

            <div class="col-md-8 col-md-offset-2">
                <form role="form" method="POST" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <legend class="text-center">Upload Your Photo</legend>

                    <fieldset>
                        <legend>Details</legend>

                        <div class="form-group col-md-6">
                            <label for="first_name">Full name</label>
                            <input type="text" class="form-control" name="fullName" placeholder="Full Name">
                        </div>

                        <div class="form-group col-md-6">
                            <label for="last_name">User name</label>
                            <input type="text" class="form-control" name="userName" id="" placeholder="User Name">
                        </div>

                        <div class="form-group col-md-12">
                            <label for="title">Photo Title</label>
                            <input type="text" class="form-control" name="title" id="" placeholder="Title of your Photo">
                        </div>

                        <div class="form-group col-md-6">
                        <legend>Catagory</legend>

                        <div class="form-group col-md-6">
                            <label for="catagory">Select Catagory</label>
                            <select class="form-control" name="catagory" id="catagory">
                                <option value="Nature" >Nature</option>
                                <option value="Wild Life" >Wild Life</option>
                                <option value="Story" >Story</option>
                                <option value="History" >Historic</option>
                                <option value="Arial" >Aerial</option>
                                <option value="Architectural" >Architectural</option>
                            </select>
                        </div>

                        </div>

                        <div class="form-group col-md-6">
                        <legend>Type</legend>
                        <label for="type">Select Type</label>
                            <div class="CatagoryType">
                            <select class="form-control" name="type" id="type">
                                <option value="Color" >Color</option>
                                <option value="Black and White" >Black and white</option>
                            </select>
                            </div>
                        </div>


                    </fieldset>

                    <fieldset>
                        <legend>Optional Details</legend>

                        <div class="form-group col-md-6">
                            
                             <div>
                                <label for="description">Description</label>
                             </div>
                             
                             <div>
                                    <input type="text" name="description">
                               <!-- <textarea name="description" rows="4" cols="50">
                                </textarea>!-->
                             </div>  
                        </div>

                    
                    
                    <Table border="1" style="margin-top:30px; margin-bottom:30px; text-align:center;"   >
                    
                        <tr>
                            <th> Choose Image </th>
                            <th> Edit Image </th>
                        </tr>
                        <tr>
                        <td>
                                <input type="file" id="upload_image" name="path" class="btn btn-warning">
                        </td>
       
                        <td>
                            <div class="btn btn-info" id="mod_image" >
                            Crop|Rotate
                            </div>
                        </td>   
                        </tr>

                    </Table>  

                    

                    <div id="popUp" class="btn btn-warning" role="dialog">
                    <div class="modal-dialog"  role="dialog">
                        <div class="modal-content">
                                <div class="modal-header">
                                <h4 class="modal-title">Crop your Image</h4>
                                </div>
                                <div class="modal-body">
                                <div class="row">
                            <div class="col-md-8 text-center">
                                <div id="image_demo" style="width:350px; margin-top:30px">  </div> <!-- img/log-icon.png !-->
                            </div>
                                <div class="col-md-4" style="padding-top:30px;">
                                    <br />
                                    <br />
                                    <br/>
                                    <div id="OK" class="btn btn-success crop_image" >Crop & Upload Image</div>
                                    <br/>
                                    <br/>
                                    <div id="rotate" class="btn btn-success rotate_image" >Rotate & Upload Image</div>
                                    <br/>
                                    <br/>
                                    <div id="close" class="btn btn-danger" >Close</div>
                                </div>
                            </div>
                    </div>

                    </fieldset>
                    <div class="form-group">
                        <div class="col-md-12">
                            <button type="submit" id="" name="submit" class="btn btn-primary">
                                PUBLISH
                            </button>
                        </div>
                    </div>

                </form>
            </div>

        </div>
    </div>



    <script>
        $(document).ready(function(){
            //$('#popUp').dialog()
            $('#popUp').hide();

            $image_crop = $('#image_demo').croppie({
            enableExif: true,
            viewport: {
            width:100,
            height:100,
            type:'square' //circle
            },
            boundary:{
            width:300,
            height:300
            }
        });


        $('#rotate').click(function(){
            $(img).rotate(90);
        });


        $('#upload_image').on('change', function(){

            var reader = new FileReader();
            reader.onload = function (event) {
            $image_crop.croppie('bind', {
                url: event.target.result
            }).then(function(){
                console.log('It works on change');
            });
            }
            reader.readAsDataURL(this.files[0]);
            var img =reader.readAsDataURL(this.files[0]);

            });
            

            $('#mod_image').on('click' ,function(){
                $('#popUp').show();
                
                var reader = new FileReader();
                reader.onload = function (event) {
                $image_crop.croppie('bind', {
                    url: event.target.result
                }).then(function(){
                    console.log('It works on click');
                });
                }
                
                $('#close').click(function(){
                $('#popUp').hide();
                });});

                
                $('.crop_image').click(function(event){
                    $image_crop.croppie('result', {
                    type: 'canvas',
                    size: 'viewport'
                    
                    })
                    $('#popUp').hide();
                });
            
 


        });  
    </script>

</body>
</html>
