<?php $__env->startSection('content'); ?>
<table border="1"  align="center" >
		<tr>
			<td>ID</td>
			<td>First Name</td>
			<td>Last Name</td>
			<td>Date of Birth</td>
			<td>User Name</td>
			<td>Password</td>
			<td>Type</td>
			<td>ACTION</td>
		</tr>

	 <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($s->id); ?></td>
            <td><?php echo e($s->firstName); ?></td>
            <td><?php echo e($s->lastName); ?></td>
            <td><?php echo e($s->DoB); ?></td>
			<td><?php echo e($s->userName); ?></td>
			<td><?php echo e($s->password); ?></td>
            <td><?php echo e($s->type); ?></td>
			
			<td>
				<a href="<?php echo e(route('update', $s->id)); ?>">Edit</a> | 
				<a href="">Delete</a> | 
				<a href="">Details</a>
			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('crud.crud', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>